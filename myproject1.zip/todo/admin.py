from django.contrib import admin
from todo.models import Todo
from todo.models import Contact
# Register your models here.
admin.site.register(Todo)
admin.site.register(Contact)